# gomoku
It's a game by two players, one of them win when make five pieces in a row. 
