package com.yjx.model;

import com.yjx.utils.Constants;

/**
 * Created by yangjinxiao on 2016/7/8.
 */
public class Settings {
    private ThemeModel model = null;

    public ThemeModel getModel() {
        return model;
    }

    public void setModel(ThemeModel model) {
        this.model = model;
    }
}
