package com.yjx.model;

import android.graphics.Point;

/**
 * Created by yangjinxiao on 2016/7/5.
 */
public class Piece extends Point {
    public static final Creator<Point> CREATOR = null;
    public Piece(int x, int y) {
        super(x, y);
    }
}
